package com.capgemini.employee.dto;

import org.springframework.stereotype.Component;

@Component
public class UserInfo {
	
	private float swagger;
	private float version;
	private String title;
	private String description;
	private String host;
	private String basePath;
	
	public float getSwagger() {
		return swagger;
	}
	public void setSwagger(float swagger) {
		this.swagger = swagger;
	}
	public float getVersion() {
		return version;
	}
	public void setVersion(float version) {
		this.version = version;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public String getBasePath() {
		return basePath;
	}
	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}

  
	
}
