package com.capgemini.employee.service;

import java.io.IOException;

import com.capgemini.employee.dto.UserInfo;

public interface IEmployeeService {

	public String getUserDetails(UserInfo userInfo) throws IOException, SecurityException, ClassNotFoundException, NoSuchFieldException;
	
}
