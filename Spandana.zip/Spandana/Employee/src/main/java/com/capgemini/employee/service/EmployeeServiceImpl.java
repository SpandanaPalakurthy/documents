package com.capgemini.employee.service;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Set;

import org.reflections.Reflections;
import org.reflections.scanners.SubTypesScanner;
import org.springframework.stereotype.Service;
import com.capgemini.employee.dto.UserInfo;

@Service
public class EmployeeServiceImpl implements IEmployeeService {

	@Override
	public String getUserDetails(UserInfo userInfo) throws IOException, NoSuchFieldException {

		FileWriter fileWriter = new FileWriter("emp.yml");
		BufferedWriter bufferWriter = new BufferedWriter(fileWriter);

		bufferWriter.write("swagger: " + "\"" + userInfo.getSwagger() + "\"");
		bufferWriter.newLine();
		bufferWriter.write("info: ");
		bufferWriter.newLine();
		bufferWriter.write("\tdescription: " + userInfo.getDescription());
		bufferWriter.newLine();
		bufferWriter.write("\tversion: " + "\"" + userInfo.getVersion() + "\"");
		bufferWriter.newLine();
		bufferWriter.write("\ttitle: " + userInfo.getTitle());
		bufferWriter.newLine();
		bufferWriter.write("host: " + userInfo.getHost());
		bufferWriter.newLine();
		bufferWriter.write("basePath: " + userInfo.getBasePath());
		bufferWriter.newLine();
		bufferWriter.write("tags: ");
		bufferWriter.newLine();
		
		bufferWriter.write("- name: ");
		bufferWriter.write("\"" +"employeeInfo" +"\"");
		bufferWriter.newLine();
		bufferWriter.write("\tdescription: ");
		bufferWriter.write("Everything about Employees");
		bufferWriter.newLine();
		bufferWriter.write("\texternalDocs: ");
		bufferWriter.newLine();
		bufferWriter.write("\t\tdescription: ");
		bufferWriter.write("Find out more");
		bufferWriter.newLine();
		bufferWriter.write("\t\turl: ");
		bufferWriter.write("http://swagger.io");
		bufferWriter.newLine();

		bufferWriter.write( "- name: ");
		bufferWriter.write("\""+"department"+ "\"");
		bufferWriter.newLine();
		bufferWriter.write("\tdescription: ");
		bufferWriter.write("Department Details");
		bufferWriter.newLine();
		bufferWriter.write("\texternalDocs: ");
		bufferWriter.newLine();
		bufferWriter.write("\t\tdescription: ");
		bufferWriter.write("Find out more");
		bufferWriter.newLine();
		bufferWriter.write("\t\turl: ");
		bufferWriter.write("http://swagger.io");
		bufferWriter.newLine();
		
		bufferWriter.write( "- name: ");
		bufferWriter.write("\""+"PersonalInfo"+ "\"");
		bufferWriter.newLine();
		bufferWriter.write("\tdescription: ");
		bufferWriter.write("Personal Details");
		bufferWriter.newLine();
		bufferWriter.write("\texternalDocs: ");
		bufferWriter.newLine();
		bufferWriter.write("\t\tdescription: ");
		bufferWriter.write("Find out more");
		bufferWriter.newLine();
		bufferWriter.write("\t\turl: ");
		bufferWriter.write("http://swagger.io");
		bufferWriter.newLine();
	
		
		bufferWriter.write("paths: ");
		bufferWriter.newLine();

//cls.getName().split(cls.getPackage().toString().split(" ")[1] + ".")[1]

		Set<Class<? extends Object>> object = getPojo();

		for (Class<? extends Object> cls : object) {
			/*
			 * bufferWriter.write("- name: " +"\"" + cls.getSimpleName() + "\"");
			 * bufferWriter.newLine(); bufferWriter.write("\tdescription:\t");
			 * bufferWriter.write("\""+" Everything about " + cls.getSimpleName() + "\"");
			 * bufferWriter.newLine();
			 **/
			
                   /********* POST METHOD**********/
			
			if ("ObjectFactory".equals(cls.getSimpleName())) {
				continue;
			} 
			bufferWriter.write("\t/" + cls.getSimpleName() + "/:");
			bufferWriter.newLine();
			bufferWriter.write("\t\tpost:\t");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\ttags: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- " + "\""+ cls.getSimpleName()+"\"");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\tsummary: ");
			bufferWriter.write("Add " + cls.getSimpleName());
			bufferWriter.newLine();
			bufferWriter.write("\t\t\toperationId: ");
			bufferWriter.write(cls.getSimpleName());
			bufferWriter.newLine();

			bufferWriter.write("\t\t\tconsumes: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- application/json");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- application/xml");
			bufferWriter.newLine();

			bufferWriter.write("\t\t\tproduces: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- application/xml");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- application/json");
			bufferWriter.newLine();

			bufferWriter.write("\t\t\tparameters: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- in: ");
			bufferWriter.write("body");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\tname: ");
			bufferWriter.write("body");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\trequired: ");
			bufferWriter.write("true");
			bufferWriter.newLine();

			bufferWriter.write("\t\t\t\tschema: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\t\t$ref: ");
			bufferWriter.write("\"" + "#/definitions/" + cls.getSimpleName() + "\"");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\tresponses: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\t200: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\t\tdescription: ");
			bufferWriter.write("Successful Operation");
			bufferWriter.newLine();
			
			/*********** GET METHOD*********/
			
			bufferWriter.write("\t/" + cls.getSimpleName() + "/fingByName"+"/:");
			bufferWriter.newLine();
			bufferWriter.write("\t\tget:\t");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\ttags: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- " + "\""+ cls.getSimpleName()+"\"");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\tsummary: ");
			bufferWriter.write("\""+"find " + cls.getSimpleName() +" ByName"+"\"");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\toperationId: ");
			bufferWriter.write("\""+"find"+cls.getSimpleName()+"ByName"+"\"");
			
			bufferWriter.newLine();

			bufferWriter.write("\t\t\tconsumes: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- application/json");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- application/xml");
			bufferWriter.newLine();

			bufferWriter.write("\t\t\tproduces: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- application/xml");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- application/json");
			bufferWriter.newLine();
			
			bufferWriter.write("\t\t\tparameters: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- name: ");
			bufferWriter.write("status");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\tin: ");
			bufferWriter.write("query");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\trequired: ");
			bufferWriter.write("true");
			bufferWriter.newLine();
			
			bufferWriter.write("\t\t\t\ttype: ");
			bufferWriter.write("array");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\titems: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\t\ttype: ");
			bufferWriter.write("string");
            bufferWriter.newLine();
			
			bufferWriter.write("\t\t\t\tcollectionFormat: ");
			bufferWriter.write("multi");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\tresponses: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\t200: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\t\tdescription: ");
			bufferWriter.write("Successful Operation");
			bufferWriter.newLine();
			
			bufferWriter.write("\t\t\t\t\tschema: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\t\t\ttype: ");
			bufferWriter.write("array");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\t\t\titems: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\t\t\t\t$ref: ");
			bufferWriter.write("\"" + "#/definitions/" + cls.getSimpleName() + "\"");
			bufferWriter.newLine();
			
			bufferWriter.write("\t\t\t\t400: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\t\tdescription: ");
			bufferWriter.write("Invalid Status Value");
			bufferWriter.newLine();
			
			/*********** PUT METHOD ************/
			
			bufferWriter.write("\t/" + cls.getSimpleName() + "/updateById"+"/:");
			bufferWriter.newLine();
			bufferWriter.write("\t\tput:\t");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\ttags: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- " + "\""+ cls.getSimpleName()+"\"");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\tsummary: ");
			bufferWriter.write("\""+"update " + cls.getSimpleName() +" ById"+"\"");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\toperationId: ");
			bufferWriter.write("\""+"update"+cls.getSimpleName()+"ById"+"\"");
			bufferWriter.newLine();

			bufferWriter.write("\t\t\tconsumes: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- application/json");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- application/xml");
			bufferWriter.newLine();
			
			bufferWriter.write("\t\t\tproduces: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- application/xml");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- application/json");
			bufferWriter.newLine();
			
			bufferWriter.write("\t\t\tparameters: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- in: ");
			bufferWriter.write("body");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\tname: ");
			bufferWriter.write("body");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\trequired: ");
			bufferWriter.write("true");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\tschema: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\t\t$ref: ");
			bufferWriter.write("\"" + "#/definitions/" + cls.getSimpleName() + "\"");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\tresponses: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\t400: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\t\tdescription: ");
			bufferWriter.write("Invalid Id Value");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\t404: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\t\tdescription: ");
			bufferWriter.write("Id not found");
			bufferWriter.newLine();
			
			/********** DELETE METHOD ********/
			
			//bufferWriter.write("\t/" + cls.getSimpleName() + "/deleteById"+"/:");
			bufferWriter.newLine();
			bufferWriter.write("\t\tdelete:\t");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\ttags: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- " + "\""+ cls.getSimpleName()+"\"");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\tsummary: ");
			bufferWriter.write("\""+"delete " + cls.getSimpleName() +" ById"+"\"");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\toperationId: ");
			bufferWriter.write("\""+"delete"+cls.getSimpleName()+"ById"+"\"");
			bufferWriter.newLine();
			
			bufferWriter.write("\t\t\tproduces: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- application/xml");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- application/json");
			bufferWriter.newLine();
			
			bufferWriter.write("\t\t\tparameters: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t- name: ");
			bufferWriter.write("Id");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\tin: ");
			bufferWriter.write("path");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\trequired: ");
			bufferWriter.write("true");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\ttype: ");
			bufferWriter.write("integer");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\tformat: ");
			bufferWriter.write("int64");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\tresponses: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\t400: ");
			bufferWriter.newLine();
			bufferWriter.write("\t\t\t\t\tdescription: ");
			bufferWriter.write("Invalid Id supplied");
			bufferWriter.newLine();

		}

		bufferWriter.write("definitions: ");
		bufferWriter.newLine();
		for (Class<? extends Object> cls : object) {
			
			if ("ObjectFactory".equals(cls.getSimpleName())) {
				continue;
			} 

			bufferWriter.write("\t" + cls.getSimpleName() + ":");
			bufferWriter.newLine();
			bufferWriter.write("\t\t properties: ");
			bufferWriter.newLine();

			for (Field field : cls.getDeclaredFields()) {

				bufferWriter.write("\t\t\t" + field.getName() + ":");
				bufferWriter.newLine();
				bufferWriter.write("\t\t\t\t type: " + simpleType(field.getType().getSimpleName()).toLowerCase());
				bufferWriter.newLine();
			}

		}
		bufferWriter.close();

		return "true";
	}

		String simpleType(String type) {

				switch (type) {

				case "BigInteger":
					return "number"; 	
				default: 
				}
				return type;
		}
		 
	public Set<Class<? extends Object>> getPojo() {
		Reflections reflections = new Reflections("com.capgemini.employee.xml", new SubTypesScanner(false));
		return reflections.getSubTypesOf(Object.class);

	}

}
