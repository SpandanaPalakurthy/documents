package com.capgemini.employee.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.employee.dto.UserInfo;
import com.capgemini.employee.service.EmployeeServiceImpl;

@RestController
public class UserController {
	
	@Autowired
	private EmployeeServiceImpl employeeService;
	
	@RequestMapping(value="/userDetails", method= RequestMethod.GET)
	public String getUserDetails(@RequestBody UserInfo userInfo) throws IOException,  NoSuchFieldException, SecurityException {
		
		return employeeService.getUserDetails(userInfo);
		
	}

}
