package com.capgemini.acp.locationservice.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * Created by spenmetc on 11/21/2019.
 */

@ApiModel(description = "Details of Region")
public @Data class RegionDTO {

    @ApiModelProperty(notes = "Country Id for Region (Foreign key to Country in Location Service)")
    private Long countryId;

    @NotNull
    @ApiModelProperty(notes = "Region Name")
    private String name;

    @NotNull
    @ApiModelProperty(notes = "Region Code")
    private String code;

}
