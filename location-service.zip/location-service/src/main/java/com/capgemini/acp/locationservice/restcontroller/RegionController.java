package com.capgemini.acp.locationservice.restcontroller;

import com.capgemini.acp.locationservice.dto.RegionDTO;
import com.capgemini.acp.locationservice.exceptions.ResourceNotFoundException;
import com.capgemini.acp.locationservice.orm.Region;
import com.capgemini.acp.locationservice.repository.CountryRepository;
import com.capgemini.acp.locationservice.repository.RegionRepository;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * Created by spenmetc on 11/21/2019.
 */

@RestController
@RequestMapping("region")
public class RegionController {
    private static final ModelMapper modelMapper = new ModelMapper();

    @Autowired
    private CountryRepository countryRepository;

    @Autowired
    private RegionRepository regionRepository;

    @GetMapping("/listAll")
    @ApiOperation(value = "Get All Regions")
    public Page<Region> listAll(Pageable pageable) {
        return regionRepository.findAll(pageable);
    }

    @PostMapping("/create")
    @ApiOperation(value = "Add new Region")
    public Region createRegion(@Valid @RequestBody RegionDTO regionDTO) {
        Region newRegion = modelMapper.map(regionDTO, Region.class);
        countryRepository.findById(regionDTO.getCountryId()).ifPresentOrElse(country -> {
            newRegion.setCountry(country);
        }, () -> {
            throw new ResourceNotFoundException("Country not found for id: " + regionDTO.getCountryId());
        });

        return regionRepository.save(newRegion);

    }

    @PutMapping("/update/{regionId}")
    @ApiOperation(value = "Update Region")
    public Region updateRegion(
            @ApiParam(value = "Id of the Region to update", required = true, example = "1") @PathVariable Long regionId,
            @Valid @RequestBody RegionDTO regionDto) {
        return regionRepository.findById(regionId).map(region -> {
            countryRepository.findById(regionDto.getCountryId()).ifPresentOrElse(country -> {
                region.setCountry(country);
            }, () -> {
                throw new ResourceNotFoundException("Country Id Not Found for id: " + regionDto.getCountryId());
            });

            region.setName(regionDto.getName());
            region.setCode(regionDto.getCode());

            return regionRepository.save(region);

        }).orElseThrow(() -> new ResourceNotFoundException("Region Not found for id: " + regionId));

    }

    @DeleteMapping("/delete/{regionId}")
    @ApiOperation(value = "Deleting The Region")
    public ResponseEntity<?> deleteRegion(
            @ApiParam(value = "Id of the Region to delete", required = true, example = "1") @PathVariable Long regionId) {
        return regionRepository.findById(regionId).map(region -> {
            regionRepository.delete(region);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException("Region Not Found with Id: " + regionId));
    }

}
