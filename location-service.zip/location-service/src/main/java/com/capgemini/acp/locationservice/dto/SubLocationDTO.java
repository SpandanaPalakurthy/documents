package com.capgemini.acp.locationservice.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@ApiModel(description = "Details of sub location")
public @Data class SubLocationDTO {

    @NotNull
    @ApiModelProperty(notes = "Sub location name")
    private String name;

    @NotNull
    @ApiModelProperty(notes = "Sub location code")
    private String code;

}
