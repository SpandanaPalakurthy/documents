package com.capgemini.acp.locationservice.restcontroller;

import com.capgemini.acp.locationservice.dto.ContinentDTO;
import com.capgemini.acp.locationservice.exceptions.ResourceNotFoundException;
import com.capgemini.acp.locationservice.orm.Continent;
import com.capgemini.acp.locationservice.repository.ContinentRepository;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * Created by spenmetc on 11/21/2019.
 */

@RestController
@RequestMapping("continent")
public class ContinentController {

    private static final ModelMapper modelMapper = new ModelMapper();

    @Autowired
    private ContinentRepository continentRepository;

    @GetMapping("/listAll")
    @ApiOperation(value = "Get All Continents")
    public Page<Continent> listAll(Pageable pageable) {
        return continentRepository.findAll(pageable);
    }

    @PostMapping("/create")
    @ApiOperation(value = "Add new Continent")
    public Continent createContinent(@Valid @RequestBody ContinentDTO continentDTO) {
        Continent continent = modelMapper.map(continentDTO, Continent.class);
        return continentRepository.save(continent);

    }

    @PutMapping("/update/{continentId}")
    @ApiOperation(value = "Update Continent")
    public Continent updateContinent(
            @ApiParam(value = "Id of Continent to update", required = true, example = "1") @PathVariable Long continentId,
            @Valid @RequestBody final ContinentDTO continentDTO) {
        return continentRepository.findById(continentId).map(continent -> {
            continent.setCode(continentDTO.getCode());
            continent.setName(continentDTO.getName());
            return continentRepository.save(continent);
        }).orElseThrow(() -> new ResourceNotFoundException("Continent Id not found: " + continentId));

    }

    @DeleteMapping("/delete/{continentId}")
    @ApiOperation(value = "Delete Continent")
    public ResponseEntity<?> deleteContinent(
            @ApiParam(value = "Id of Continent to delete", required = true, example = "1") @PathVariable Long continentId) {
        return continentRepository.findById(continentId).map(continent -> {
            continentRepository.delete(continent);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException("Continent Not found for id: " + continentId));

    }

}
