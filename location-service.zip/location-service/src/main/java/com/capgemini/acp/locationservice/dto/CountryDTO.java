package com.capgemini.acp.locationservice.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * Created by spenmetc on 11/21/2019.
 */

@ApiModel(description = "Details of Country")
@Data
public class CountryDTO {

    @ApiModelProperty(notes = "Continent Id for country (Foreign key to Continent in Location Service)")
    private Long continentId;

    @NotNull
    @ApiModelProperty(notes = "Country name")
    private String name;

    @NotNull
    @ApiModelProperty(notes = "Country code")
    private String code;

}
