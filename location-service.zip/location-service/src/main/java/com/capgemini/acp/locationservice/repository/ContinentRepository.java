package com.capgemini.acp.locationservice.repository;

import com.capgemini.acp.locationservice.orm.Continent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by spenmetc on 11/21/2019.
 */

@Repository
public interface ContinentRepository extends JpaRepository<Continent, Long> {


}
