
package com.capgemini.acp.locationservice.orm;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@org.hibernate.annotations.Proxy(lazy = false)
@Table(name = "Country")
public class Country implements Serializable {
	public Country() {
	}

	@Column(name = "ID", nullable = false)
	@Id
	@GeneratedValue(generator = "COM_CAPGEMINI_ACP_LOCATIONSERVICE_ORM_COUNTRY_ID_GENERATOR")
	@org.hibernate.annotations.GenericGenerator(name = "COM_CAPGEMINI_ACP_LOCATIONSERVICE_ORM_COUNTRY_ID_GENERATOR", strategy = "sequence", parameters = {
			@org.hibernate.annotations.Parameter(name = "sequence", value = "seq_Country") })
	private long ID;

	@ManyToOne(targetEntity = com.capgemini.acp.locationservice.orm.Continent.class)
	@org.hibernate.annotations.Cascade({ org.hibernate.annotations.CascadeType.LOCK })
	@JoinColumns(value = {
			@JoinColumn(name = "ContinentID", referencedColumnName = "ID", nullable = false) }, foreignKey = @ForeignKey(name = "FKCountry760212"))
	private com.capgemini.acp.locationservice.orm.Continent continent;

	@Column(name = "Name", nullable = false, length = 255)
	private String name;

	@Column(name = "Code", nullable = false, unique = true, length = 255)
	private String code;

	private void setID(long value) {
		this.ID = value;
	}

	public long getID() {
		return ID;
	}

	public void setName(String value) {
		this.name = value;
	}

	public String getName() {
		return name;
	}

	public void setCode(String value) {
		this.code = value;
	}

	public String getCode() {
		return code;
	}

	public void setContinent(com.capgemini.acp.locationservice.orm.Continent value) {
		this.continent = value;
	}

	public com.capgemini.acp.locationservice.orm.Continent getContinent() {
		return continent;
	}

	public String toString() {
		return toString(false);
	}

	public String toString(boolean idOnly) {
		if (idOnly) {
			return String.valueOf(getID());
		} else {
			StringBuffer sb = new StringBuffer();
			sb.append("Country[ ");
			sb.append("ID=").append(getID()).append(" ");
			if (getContinent() != null)
				sb.append("Continent.Persist_ID=").append(getContinent().toString(true)).append(" ");
			else
				sb.append("Continent=null ");
			sb.append("Name=").append(getName()).append(" ");
			sb.append("Code=").append(getCode()).append(" ");
			sb.append("]");
			return sb.toString();
		}
	}

}
