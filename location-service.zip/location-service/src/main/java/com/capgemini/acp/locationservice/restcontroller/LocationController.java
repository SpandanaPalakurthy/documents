package com.capgemini.acp.locationservice.restcontroller;

import com.capgemini.acp.locationservice.dto.LocationDTO;
import com.capgemini.acp.locationservice.exceptions.ResourceNotFoundException;
import com.capgemini.acp.locationservice.orm.Location;
import com.capgemini.acp.locationservice.repository.LocationRepository;
import com.capgemini.acp.locationservice.repository.RegionRepository;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * Created by spenmetc on 11/21/2019.
 */

@RestController
@RequestMapping("/location")
public class LocationController {

    private static final ModelMapper modelMapper = new ModelMapper();

    @Autowired
    private RegionRepository regionRepository;

    @Autowired
    private LocationRepository locationRepository;

    @GetMapping("/listall")
    @ApiOperation(value = "Get All Locations")
    public Page<Location> listAll(Pageable pageable) {
        return locationRepository.findAll(pageable);
    }
    
    @PostMapping("{regionId}/create-location")
    @ApiOperation(value = "Create Main Location to particular Region")
    public Location createLocation(
            @ApiParam(value = "Region Id for the new Location to be created", required = true, example = "1") @PathVariable Long regionId,
            @Valid @RequestBody LocationDTO locationDTO) {
        Location location = modelMapper.map(locationDTO, Location.class);
        regionRepository.findById(regionId).ifPresentOrElse(region -> {
            location.setRegion(region);
        }, () -> {
            throw new ResourceNotFoundException("Region not found for the id:" + regionId);
        });
        return locationRepository.save(location);
    }

    @PostMapping("/{parentLocationId}/create-sublocation")
    @ApiOperation(value = "Add sub-location for the given Parent Location")
    public Location createSubLocation(
            @ApiParam(value = "Location Id for new sub-location to be created", required = true, example = "1") @PathVariable Long parentLocationId,
            @Valid @RequestBody Location location) {
        locationRepository.findById(parentLocationId).ifPresentOrElse((parentLocation -> {
            location.setParentLocation(parentLocation);
        }), () -> {
            throw new ResourceNotFoundException("Location not found for Id: " + parentLocationId);
        });

        return locationRepository.save(location);

    }

    @PutMapping("/update/{locationId}")
    @ApiOperation(value = "Update Location")
    public Location updateLocation(
            @ApiParam(value = "Id for the location to update", required = true, example = "1") @PathVariable Long locationId,
            @Valid @RequestBody LocationDTO locationDTO) {
        return locationRepository.findById(locationId).map(location -> {
            regionRepository.findById(locationDTO.getRegionId()).ifPresentOrElse((region -> {
                location.setRegion(region);
            }), () -> {
                throw new ResourceNotFoundException("Region not found for Id: " + locationDTO.getRegionId());
            });
            location.setName(locationDTO.getName());
            location.setCode(locationDTO.getCode());
            return locationRepository.save(location);
        }).orElseThrow(() -> new ResourceNotFoundException("Location not found for Id: " + locationId));

    }
    
    @DeleteMapping("/delete/{locationId}")
    @ApiOperation(value = "Deleting the location")
    public ResponseEntity<?> deleteLocation(
            @ApiParam(value = "Id of the Location to delete", required = true, example = "1") @PathVariable Long locationId) {
        return locationRepository.findById(locationId).map(location -> {
            locationRepository.delete(location);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException("Location Not found with Id: " + locationId));
    }

}
