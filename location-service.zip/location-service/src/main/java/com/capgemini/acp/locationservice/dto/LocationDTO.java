package com.capgemini.acp.locationservice.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * Created by spenmetc on 11/21/2019.
 */
@ApiModel(description = "Details of Location")
public @Data class LocationDTO {

    @NotNull
    @ApiModelProperty(notes = "Region Id for Location (Foreign key to Region in Location Service )")
    private Long regionId;

    @NotNull
    @ApiModelProperty(notes = "Location Name")
    private String name;

    @NotNull
    @ApiModelProperty(notes = "Location Code")
    private String code;

}
