package com.capgemini.acp.locationservice.restcontroller;

import com.capgemini.acp.locationservice.dto.CountryDTO;
import com.capgemini.acp.locationservice.exceptions.ResourceNotFoundException;
import com.capgemini.acp.locationservice.orm.Country;
import com.capgemini.acp.locationservice.repository.ContinentRepository;
import com.capgemini.acp.locationservice.repository.CountryRepository;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * Created by spenmetc on 11/21/2019.
 */
@RestController
@RequestMapping("country")
public class CountryController {

    private static final ModelMapper modelMapper = new ModelMapper();

    @Autowired
    private CountryRepository countryRepository;

    @Autowired
    private ContinentRepository continentRepository;

    @GetMapping("/listAll")
    @ApiOperation(value = "Get All Countries")
    public Page<Country> listAll(Pageable pageable) {
        return countryRepository.findAll(pageable);
    }
    

    @PostMapping("/create")
    @ApiOperation(value = "Add new Country")
    public Country createCountry(@Valid @RequestBody CountryDTO countryDto) {

        Country newCountry = modelMapper.map(countryDto, Country.class);
        // Long continentId = country.getContinent().getID();
        continentRepository.findById(countryDto.getContinentId()).ifPresentOrElse(continent -> {
            newCountry.setContinent(continent);
        }, () -> {
            throw new ResourceNotFoundException("Continent Not Found for id: " + countryDto.getContinentId());
        });
        return countryRepository.save(newCountry);

    }

    @PutMapping("/update/{countryId}")
    @ApiOperation(value = "Update Country")
    public Country updateCountry(
            @ApiParam(value = "Id of Country to update", required = true, example = "1") @PathVariable Long countryId,
            @Valid @RequestBody CountryDTO countryDTO) {
        return countryRepository.findById(countryId).map(country -> {

            continentRepository.findById(countryDTO.getContinentId()).ifPresentOrElse(continent -> {
                country.setContinent(continent);
            }, () -> {
                throw new ResourceNotFoundException("Continent Not Found for id: " + countryDTO.getContinentId());
            });
            country.setName(countryDTO.getName());
            country.setCode(countryDTO.getCode());
            return countryRepository.save(country);
        }).orElseThrow(() -> new ResourceNotFoundException("Country Not Found for Id: " + countryId));
    }

    @DeleteMapping("/delete/{countryId}")
    @ApiOperation(value = "Deleting the Country")
    public ResponseEntity<?> deleteCountry(
            @ApiParam(value = "Id of the Country to delete", required = true, example = "1") @PathVariable Long countryId) {
        return countryRepository.findById(countryId).map(country -> {
            countryRepository.delete(country);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException("Country Not Found with id: " + countryId));

    }

}
