package com.capgemini.acp.locationservice.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * Created by spenmetc on 11/21/2019.
 */

@ApiModel(description = "Details of Continent")
public @Data class ContinentDTO {

    @NotNull
    @ApiModelProperty(notes = "Continent name")
    private String name;

    @NotNull
    @ApiModelProperty(notes = "Continent code")
    private String code;

}
