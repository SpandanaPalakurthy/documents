
package com.capgemini.acp.locationservice.orm;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@org.hibernate.annotations.Proxy(lazy = false)
@Table(name = "Continent")
public class Continent implements Serializable {
	public Continent() {
	}

	@Column(name = "ID", nullable = false)
	@Id
	@GeneratedValue(generator = "COM_CAPGEMINI_ACP_LOCATIONSERVICE_ORM_CONTINENT_ID_GENERATOR")
	@org.hibernate.annotations.GenericGenerator(name = "COM_CAPGEMINI_ACP_LOCATIONSERVICE_ORM_CONTINENT_ID_GENERATOR", strategy = "sequence", parameters = {
			@org.hibernate.annotations.Parameter(name = "sequence", value = "seq_Continent") })
	private long ID;

	@Column(name = "Name", nullable = false, length = 255)
	private String name;

	@Column(name = "Code", nullable = false, unique = true, length = 255)
	private String code;

	private void setID(long value) {
		this.ID = value;
	}

	public long getID() {
		return ID;
	}

	public void setName(String value) {
		this.name = value;
	}

	public String getName() {
		return name;
	}

	public void setCode(String value) {
		this.code = value;
	}

	public String getCode() {
		return code;
	}

	public String toString() {
		return toString(false);
	}

	public String toString(boolean idOnly) {
		if (idOnly) {
			return String.valueOf(getID());
		} else {
			StringBuffer sb = new StringBuffer();
			sb.append("Continent[ ");
			sb.append("ID=").append(getID()).append(" ");
			sb.append("Name=").append(getName()).append(" ");
			sb.append("Code=").append(getCode()).append(" ");
			sb.append("]");
			return sb.toString();
		}
	}

}
