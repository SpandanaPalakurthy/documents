package com.capgemini.acp.locationservice.repository;

import com.capgemini.acp.locationservice.orm.Country;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by spenmetc on 11/21/2019.
 */
public interface CountryRepository extends JpaRepository<Country, Long>{
}
