package com.capgemini.acp.locationservice.repository;

import com.capgemini.acp.locationservice.orm.Location;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by spenmetc on 11/21/2019.
 */
public interface LocationRepository extends JpaRepository<Location, Long> {


}
