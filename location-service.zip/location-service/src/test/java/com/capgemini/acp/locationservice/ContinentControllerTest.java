 package com.capgemini.acp.locationservice;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.util.ReflectionUtils;
import org.springframework.test.context.ContextConfiguration;

import com.capgemini.acp.locationservice.dto.ContinentDTO;
import com.capgemini.acp.locationservice.orm.Continent;
import com.capgemini.acp.locationservice.repository.ContinentRepository;
import com.capgemini.acp.locationservice.repository.CountryRepository;
import com.capgemini.acp.locationservice.repository.LocationRepository;
import com.capgemini.acp.locationservice.repository.RegionRepository;
import com.capgemini.acp.locationservice.restcontroller.ContinentController;

@RunWith(MockitoJUnitRunner.class)
@ContextConfiguration
public class ContinentControllerTest {

	@InjectMocks
	private ContinentController continentController;

	@Mock
	private ContinentRepository continentRepository;

	@Mock
	private CountryRepository countryRepository;

	@Mock
	private LocationRepository locationRepository;

	@Mock
	private RegionRepository regionRepository;

	@Mock
	private Pageable pageable;

	@Test
	public void createContinentTest() {
		ContinentDTO conActual = new ContinentDTO();
		conActual.setCode("AU1");
		conActual.setName("asia");
		Continent continentORM = new Continent();
		continentORM.setCode("AU1");
		continentORM.setName("asia");
		when(continentRepository.save(Mockito.any())).thenReturn(continentORM);
		continentController.createContinent(conActual);
		Mockito.verify(continentRepository).save(Mockito.any());
	}

	
	@Test
	public void listAllTest() {
		
		Page<Continent> continentactual = Mockito.mock(Page.class);
		Mockito.when(continentRepository.findAll(pageable)).thenReturn(continentactual);
		Page<Continent> continentExpected = continentController.listAll(pageable);
		assertEquals(continentExpected, continentactual);
	}

	@Test
	public void updateContinentTest() {
		ContinentDTO conActual = new ContinentDTO();
		conActual.setCode("AAA");
		conActual.setName("AUS");

		Continent continent = new Continent();
		continent.setCode("AAA");
		continent.setName("AUS");
		when(continentRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(continent));
		when(continentRepository.save(Mockito.any())).thenReturn(continent);
		continentController.updateContinent(12L, conActual);
		Mockito.verify(continentRepository).save(Mockito.any());

	}

	@Test
	public void deleteContinentTest() {
		ContinentDTO conActual = new ContinentDTO();
		when(continentRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(new Continent()));
		Mockito.doNothing().when(continentRepository).delete(Mockito.any());
		continentController.deleteContinent(12L);

	}

	
}
