package com.capgemini.acp.locationservice;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.ContextConfiguration;

import com.capgemini.acp.locationservice.dto.CountryDTO;
import com.capgemini.acp.locationservice.dto.RegionDTO;
import com.capgemini.acp.locationservice.orm.Country;
import com.capgemini.acp.locationservice.orm.Region;
import com.capgemini.acp.locationservice.repository.CountryRepository;
import com.capgemini.acp.locationservice.repository.RegionRepository;
import com.capgemini.acp.locationservice.restcontroller.RegionController;
import java.util.Optional;

@RunWith(MockitoJUnitRunner.class)
@ContextConfiguration
public class RegionControllerTest {

	@InjectMocks
	private RegionController regioncontroller;

	@Mock
	private RegionRepository regionRepository;

	@Mock
	private CountryRepository countryRepository;

	@Mock
	private Pageable pageable;

	@Test
	public void listAllTest() {
		Page<Region> regiontactual = Mockito.mock(Page.class);
		Mockito.when(regionRepository.findAll(pageable)).thenReturn(regiontactual);
		Page<Region> regionExpected = regioncontroller.listAll(pageable);
		assertEquals(regionExpected, regiontactual);
	}

	@Test
	public void createRegionTest() {
		RegionDTO regiondto = new RegionDTO();
		regiondto.setCode("hyd");
		regiondto.setName("hyderabad");
		regiondto.setCountryId(8L);

		Country countryorm = new Country();
		countryorm.setCode("In");
		countryorm.setName("India");

		when(countryRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(countryorm));
		regioncontroller.createRegion(regiondto);
		Mockito.verify(regionRepository).save(Mockito.any());

	}

	@Test
	public void updateRegionTest() {
		RegionDTO regiondto = new RegionDTO();
		regiondto.setCode("hyd");
		regiondto.setName("hyd");
		regiondto.setCountryId(8L);

		Region region = new Region();
		region.setCode("hyd");
		region.setName("hyd");

		Country country = new Country();
		when(regionRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(region));
		when(countryRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(country));
		when(regionRepository.save(Mockito.any())).thenReturn(region);
		regioncontroller.updateRegion(8L, regiondto);
		Mockito.verify(regionRepository).save(Mockito.any());
		

	}

	@Test
	public void deleteRegionTest() {
		RegionDTO regiondto = new RegionDTO();
		when(regionRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(new Region()));
		Mockito.doNothing().when(regionRepository).delete(Mockito.any());
		regioncontroller.deleteRegion(9L);
}


}
