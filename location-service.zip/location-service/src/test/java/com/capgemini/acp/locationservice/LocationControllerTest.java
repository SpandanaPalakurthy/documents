package com.capgemini.acp.locationservice;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.ContextConfiguration;

import com.capgemini.acp.locationservice.dto.LocationDTO;
import com.capgemini.acp.locationservice.dto.SubLocationDTO;
import com.capgemini.acp.locationservice.orm.Country;
import com.capgemini.acp.locationservice.orm.Location;
import com.capgemini.acp.locationservice.orm.Region;
import com.capgemini.acp.locationservice.repository.LocationRepository;
import com.capgemini.acp.locationservice.repository.RegionRepository;
import com.capgemini.acp.locationservice.restcontroller.LocationController;

@RunWith(MockitoJUnitRunner.class)
@ContextConfiguration
public class LocationControllerTest {

	@InjectMocks
	private LocationController locationcontroller;

	@Mock
	private LocationRepository locationRepository;

	@Mock
	private RegionRepository regionRepository;

	@Mock
	private Pageable pageable;

	@Test
	public void listAllTest() {

		Page<Location> locationtactual = Mockito.mock(Page.class);
		Mockito.when(locationRepository.findAll(pageable)).thenReturn(locationtactual);
		Page<Location> locationtExpected = locationcontroller.listAll(pageable);
		assertEquals(locationtExpected, locationtactual);

	}

	@Test
	public void createLocationTest() {
		LocationDTO locationdto = new LocationDTO();
		locationdto.setCode("TG");
		locationdto.setName("telangana");
		locationdto.setRegionId(9L);

		Region regionorm = new Region();
		regionorm.setCode("aa");
		regionorm.setName("abc");
		when(regionRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(regionorm));
		locationcontroller.createLocation(9L, locationdto);
		Mockito.verify(locationRepository).save(Mockito.any());
	}

	

	@Test
	public void updateLocationTest() {
		LocationDTO locationdto = new LocationDTO();
		locationdto.setCode("hy");
		locationdto.setName("hyd");
		locationdto.setRegionId(9L);
		
		Location location = new Location();
		location.setCode("hy");
		location.setName("hyd");
		Region region = new Region();
		when(locationRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(location));
		when(regionRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(region));
		when(locationRepository.save(Mockito.any())).thenReturn(location);
		locationcontroller.updateLocation(9L, locationdto);
		Mockito.verify(locationRepository).save(Mockito.any());

	}
	
	@Test
	public void deleteLocationTest() {
		when(locationRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(new Location()));
		Mockito.doNothing().when(locationRepository).delete(Mockito.any());
		locationcontroller.deleteLocation(9L);
	}
}
