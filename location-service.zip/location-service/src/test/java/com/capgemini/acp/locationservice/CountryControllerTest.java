package com.capgemini.acp.locationservice;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.ContextConfiguration;

import com.capgemini.acp.locationservice.dto.CountryDTO;
import com.capgemini.acp.locationservice.orm.Continent;
import com.capgemini.acp.locationservice.orm.Country;
import com.capgemini.acp.locationservice.repository.ContinentRepository;
import com.capgemini.acp.locationservice.repository.CountryRepository;
import com.capgemini.acp.locationservice.restcontroller.ContinentController;
import com.capgemini.acp.locationservice.restcontroller.CountryController;

@RunWith(MockitoJUnitRunner.class)
@ContextConfiguration
public class CountryControllerTest {

	@InjectMocks
	private CountryController countrycontroller;

	@Mock
	private CountryRepository countryRepository;

	@Mock
	private ContinentRepository continentRepository;

	@InjectMocks
	private ContinentController continentcontroller;

	@Mock
	private Pageable pageable;

	@Test
	public void createCountryTest() {
		CountryDTO countryactual = new CountryDTO();
		countryactual.setCode("IN");
		countryactual.setName("India");
		countryactual.setContinentId(12L);
		Continent continentORM = new Continent();
		continentORM.setCode("IN");
		continentORM.setName("India");
	

		when(continentRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(continentORM));
		countrycontroller.createCountry(countryactual);
		Mockito.verify(countryRepository).save(Mockito.any());

	}

	@Test
	public void listAllTest() {
		Page<Country> countryactual = Mockito.mock(Page.class);
		Mockito.when(countryRepository.findAll(pageable)).thenReturn(countryactual);
		Page<Country> countryexpected = countrycontroller.listAll(pageable);
		assertEquals(countryexpected, countryactual);

	}

	@Test
	public void updateCountryTest() {
		CountryDTO countryactual = new CountryDTO();
		countryactual.setCode("uks");
		countryactual.setName("uk");
		countryactual.setContinentId(12L);

		Country country = new Country();
		country.setCode("uks");
		country.setName("uk");
		Continent continent = new Continent();
		when(countryRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(country));
		when(continentRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(continent));
		when(countryRepository.save(Mockito.any())).thenReturn(country);
		countrycontroller.updateCountry(1L, countryactual);
		Mockito.verify(countryRepository).save(Mockito.any());

	}

	@Test
	public void deleteCountryTest() {
		CountryDTO country = new CountryDTO();
		when(countryRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(new Country()));
		Mockito.doNothing().when(countryRepository).delete(Mockito.any());
		countrycontroller.deleteCountry(12L);
	}

}
